package movieTicket;

class user{
    String name,username,password,address,phone;
    public void buyticket(){

    }
    public void showticket(){

    }
    public void cancelTickect(){

    }
    public void logout(){

    }
}
class Admin extends user{
    void addMovies(){

    }
    void selectMovies(){
        
    }

}
public class movieTicketLogin {
}
